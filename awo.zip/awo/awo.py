
import os
import discord
from redbot.core import commands
from redbot.core.config import Config
from redbot.core.utils.chat_formatting import pagify

class Awo(commands.Cog):
    

    def __init__(self, bot):
        self.bot = bot
        self.pic = 'https://cdn.pixabay.com/photo/2022/04/01/15/41/wolf-7105065_960_720.jpg'
        self.image = ""
        self.pic_path = os.getcwd() + '\\redenv\\Lib\\site-packages\\redbot\\cogs\\awo\\wolf.jpg'
        
    @commands.command()
    async def awo(self, ctx):
        
        await ctx.channel.send(file=discord.File(self.pic_path, 'wolf.jpg'))
        await ctx.channel.send(f'AWOOOOOOOOOoooooOOOOOOOOOOOOOOOOOOOOOOOOOOOOO')